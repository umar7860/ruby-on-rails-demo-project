class BugsController < ApplicationController

	def index

		@list = Bug.all

		@project_details =Project.find(params[:project_id])
		@bugs_details = @project_details.bugs

		


	end


	def create

		@project= Project.find(params[:project_id])

		@bug = @project.bugs.create(bug_params)
		respond_to do |format|
   		if @bug.save
      		#format.html { redirect_to root_path, notice: "Bug was successfully created." }
      		
      		format.html {redirect_to project_bugs_path(@project,@selected_bug), notice: "Bug was successfully created." }
         

      	else
         format.html { render :new, status: :unprocessable_entity }
         

      	end

   end






		
    end
    def show

  		@selected_bug = Bug.find(params[:id])
  		
  		@project=@selected_bug.project
  		#@dev_list = @project.users.developer

  		@dev_list = @project.users.developer.where.not(id: @selected_bug.dev_id)


    end

	def new
		
		@project= Project.find(params[:project_id])

		@bug = @project.bugs.new
	end

	def edit
		@project= Project.find(params[:project_id])

		@selected_bug = Bug.find(params[:id])
	end


  	def assign_dev

  		
  		@selected_dev= User.find(params[:dev_id])
  		@selected_bug = Bug.find(params[:id])

  		#@selected_bug.update_column(:dev_id => @selected_dev)
  		@selected_bug.update_column(:dev_id , params[:dev_id] )

  		redirect_to  :projects,notice: "Developer Assigned"

  	end

  	def destroy
  		@selected_bug = Bug.find(params[:id])
  		@selected_bug.destroy

  		respond_to do |format|
      	format.html { redirect_to projects_path,notice:"Bug Removed" }
      end

  	end

  	def update

  		@project= Project.find(params[:project_id])

		@selected_bug = Bug.find(params[:id])

		respond_to do |format|
			if @selected_bug.update(bug_params)
				format.html { redirect_to project_bugs_path(@project,@selected_bug), notice: "Your Bug Details Updated"}
			else
         		format.html {render :edit,status: :ok, location:@projects}
      		end


		end


  	end



	def bug_params
    	params.require(:bug).permit(:title, :deadline, :status,:description, :bug_type,:image).merge(user_id:current_user.id)
  	end
end
