class HomeController < ApplicationController
 
end