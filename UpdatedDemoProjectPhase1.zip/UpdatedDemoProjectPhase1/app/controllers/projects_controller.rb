class ProjectsController < ApplicationController
   before_action :get_current_user, only: [:createUserAganistProject,:edit,:create,:destroy,:show,:index]
   before_action :user_is_logged_in
   def index

      @projects = @user.projects
      @user = current_user
      @all_projects = Project.all
      user_type = current_user.user_type

      
      # if user_signed_in?
      #    #@projects = Project.all
      # else
      #    #redirect_to new_user_registration_path
      # end





   end
   def new
    @projects = Project.new

 end

 def create

  @projects = @user.projects.create(project_params)
  respond_to do |format|
   if @projects.save
      format.html { redirect_to @projects, notice: "Project was successfully created." }
       

      else
         format.html { render :new, status: :unprocessable_entity }
        


      end

   end

end
def edit
  @projects = Project.find(params[:id])

end
def update
   @projects = Project.find(params[:id])
   respond_to do |format|
      if @projects.update(project_params)
         format.html { redirect_to @projects, notice: "Your projects Details Updated"}
         
      else
         format.html {render :edit,status: :ok, location:@projects}
      end



   end

end
def show
   @project_details = Project.find(params[:id])


   @bugs_details = @project_details.bugs
   #Getting the list of all the users


   @user = @project_details.users


end

def destroy

   @projects = Project.find(params[:id])
   @projects.destroy

   respond_to do |format|
      format.html { redirect_to projects_path,notice:"Project Removed" }
   end
end
   def create_user_aganist_project

       @projects = Project.find(params[:id])
       @user = current_user
       
       @user_all = User.all
         

      @updated_user1= User.where.not(id: @projects.users.ids)
      @updated_user = @updated_user1.where.not(user_type:2)

      


   end


   



   def project_params
   params.require(:project).permit(:name, :start_date)
   end


   def get_current_user
      #@user = current_user
      @user ||= current_user
      
   end
   def add_user
      
      @user  = current_user

      @selected_user = User.find(params[:user_id])
      @selected_project = Project.find(params[:project_id])

      qurey = @selected_project.user_projects.new(user_id: @selected_user.id)
      qurey.save!
      redirect_to :projects, notice: "User Assigned"

     
   end

end



