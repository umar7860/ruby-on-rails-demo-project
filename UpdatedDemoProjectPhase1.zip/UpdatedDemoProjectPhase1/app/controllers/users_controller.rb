class UserController < ApplicationController
end
