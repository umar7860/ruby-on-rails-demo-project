 class Ability
  include CanCan::Ability

  def initialize(user)


    if user.manager?




    else
      can :update, Bug do |bug|
        bug.user == user
      can :destroy, Bug do |bug|
        bug.user == user
      can :edit, Bug do |bug|
        bug.user == user


    end






  end
end
