class Bug < ApplicationRecord
  belongs_to :user , :class_name => 'User' , optional: true
  belongs_to :dev   , :class_name => 'User' , optional: true
  belongs_to :project


  validates :title, presence: true ,:uniqueness => {:message => "Title already exists."}
 
  mount_uploader :image, ImageUploader

  enum bug_type: [:Feature, :Bug]
  #enum status: [:New , :Started,:Completed, :Resolved]
  

  
end
