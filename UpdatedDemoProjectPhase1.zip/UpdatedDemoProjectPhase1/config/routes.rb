Rails.application.routes.draw do
 devise_for :users , path: '', path_names: {sign_in: 'login', sign_out: 'logout',sign_up:'register'}


 #get 'project', to: 'home#createProjects'

 #post 'projects', to: 'home#create' # create

  resources :projects do 

    resources :bugs

  end

  

  get 'list_of_users/:id', to: 'projects#create_user_aganist_project' , as: 'show_users'

  post 'add_user/:id', to: 'projects#add_user' , as: 'user_added'

  get '/bugs/:id/add_dev/:dev_id', to: 'bugs#assign_dev' , as: 'assign_dev'

  

  root to: "projects#index"
end
