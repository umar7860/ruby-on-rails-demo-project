class CreateBugs < ActiveRecord::Migration[5.1]
  def change
    create_table :bugs do |t|
      t.string :title
      t.datetime :deadline
      t.text :description
      
      t.column :status, :string , default:"New"
      t.column :bug_type, :integer, default:0
      
      t.references :user, foreign_key: { to_table: :users }
      t.references :dev, foreign_key: { to_table: :users }

      t.timestamps
    end
     
  end
end
